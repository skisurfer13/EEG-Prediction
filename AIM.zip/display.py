import streamlit as st
import pandas as pd
import pickle

with open('y_test.pkl', 'rb') as f:
    y_test = pickle.load(f)


def load_results(file_path):
    return pd.read_pickle(file_path)



import matplotlib.pyplot as plt

def display_predictions(index, results_dfs):
    class_labels = {0: 'Preictal', 1: 'Interictal', 2: 'Ictal'}
    correct_label = class_labels[y_test[index]]
    st.write(f"Sample Index: {index}")
    st.write(f"**Correct Label: {correct_label}**")
    for model_name, df in results_dfs.items():
        st.write(f"**{model_name} Predictions:**")
        predicted_class = df.iloc[index]['Predictions']
        st.write(f"Predicted Class: {class_labels[predicted_class]}")
        probabilities = df.iloc[index]['Probabilities']
        probabilities_percent = [prob * 100 for prob in probabilities]
        
        # Set up the labels and values for Matplotlib bar chart
        labels = list(class_labels.values())
        values = probabilities_percent
        
        # Create bar chart using Matplotlib
        fig, ax = plt.subplots()
        ax.bar(labels, values)
        ax.set_ylabel('Probabilities (%)')
        ax.set_title(f'{model_name} Predictions')
        
        # Display the Matplotlib bar chart in Streamlit
        st.pyplot(fig)



# Load data from all models
#
models = ['rf', 'ada', 'svm', 'cnn', 'knn']
results_dfs = {model: load_results(f"{model}_pred.pkl") for model in models}

sample_index = st.slider('Select Sample Index', 0, len(results_dfs['cnn']) - 1, 0)

if st.button('Show Predictions'):
    display_predictions(sample_index, results_dfs)
